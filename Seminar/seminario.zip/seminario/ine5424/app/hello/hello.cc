#include <utility/ostream.h>
#include <machine/riscv/riscv_ic.h>
#include <machine/riscv/riscv_uart.h>

using namespace EPOS;

OStream cout;

int main()
{
    IC::ipi(1, CLINT::IRQ_MAC_SOFT);

    return 0;
}
