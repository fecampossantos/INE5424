// EPOS PC AES Mediator Declarations

#ifndef __pc_aes_h
#define __pc_aes_h

#include <machine/aes.h>

__BEGIN_SYS

//TODO: this is just a place holder. Replace with x86 AES!
template<unsigned int KEY_SIZE>
class AES;

__END_SYS

#endif
